import tkinter as tk
from tkinter import ttk
from PIL import Image, ImageTk

glav_okn = tk.Tk()
glav_okn.title("Pubg Karti")
glav_okn.geometry("1600x900")

slovar = {
    'Э': {
        'title': 'Эрангель',
        'content': '''Эрангель - это самая первая карта в PUBG. 

Из себя представляет вымышленный остров в Черном море. 

История острова начинается в 1950-х. Советский союз вторгся на остров и начал использовать его как полигон. 

Конечно же, жителям острова это не понравилось. Началось массовое сопротивление власти и в итоге военным пришлось применить силовые поля.''',
        'image': '76.jpg'
    },
    'М': {
        'title': 'Мирамар',
        'content': '''Мирамар была второй картой, выпущенной для PUBG. 

Действие происходит в мексиканской пустыне с большим городом и несколькими небольшими деревнями. 

Она очень похожа на карту Эрангель, в основном из-за схожих размеров и необходимости ведения дальнего боя. 

Лучшие места с добычей:
- Тюрьма
- Гасьенда-дель-Патрон (вилла)
- Города Лос-Леонес и Эль-Посо''',
        'image': 'mir.jpg'
    },
    'В': {
        'title': 'Викенди',
        'content': '''Викенди - почти полностью покрытый снегом курортный остров в Адриатическом море. 

Он немного меньше Эрангеля и Мирамара, но из-за гористой местности и густых лесов компактным он отнюдь не ощущается. 

Особенности:
- Много естественных укрытий
- Возможности для стелса
- Следы на снегу помогают отслеживать противников''',
        'image': 'vik.jpg'
    },
    'С': {
        'title': 'Санок',
        'content': '''Санок - карта, перенесшая PUBG в Азию, на остров с пышными джунглями. 

Особенности:
- Вдохновлена Таиландом и Филиппинами
- Динамический круг бури (корректируется в середине игры)
- Акцент на ближнем бою
- Густая растительность джунглей
- Небольшие размеры локаций''',
        'image': 'san.jpg'
    },
    'К': {
        'title': 'Каракин',
        'content': '''Каракин - африканская карта небольшого размера. 

Особенности:
- Максимум 64 игрока (вместо 100)
- Похожа на Мирамар (открытые области с малым количеством укрытий)
- Быстрый темп игры (как на Санок)
- Туннели для скрытного перемещения
- Возможность фланговых атак''',
        'image': 'karkin.jpg'
    },
    'П': {
        'title': 'Парамо',
        'content': '''Парамо - самая динамичная карта в игре. 

Особенности:
- Активный вулкан в центре (меняет ландшафт)
- Изменяющееся расположение достопримечательностей
- Секретные комнаты с ключами
- Каждый матч проходит по-разному
- Сложность в изучении карты''',
        'image': 'paramo.jpg'
    },
    'Т': {
        'title': 'Таэго',
        'content': '''Таэго - карта размером 8×8 (как Эрангель и Мирамар). 

Особенности:
- Вдохновлена Южной Кореей 90-х
- Множество достопримечательностей
- Открытые пространства для дальнего боя
- Деревни и города для ближнего боя
- Секретные комнаты с ключами (как на Парамо)''',
        'image': 'tag.jpg'
    },
    'Д': {
        'title': 'Дестон',
        'content': '''Дестон - новая карта PUBG. 

Особенности:
- Самая большая карта в истории игры (9×9 или 10×10)
- Первоначально называлась "Кики"
- Планируется к выпуску в текущем году
- Новые игровые механики
- Уникальный ландшафт''',
        'image': 'dest.jpg'
    }
}
main = ttk.Frame(glav_okn)
main.pack(fill=tk.BOTH, expand=True, padx=10, pady=10)

sodersh_frame = ttk.Frame(main)
sodersh_frame.pack(fill=tk.BOTH, expand=True)

bukvi_frame = ttk.LabelFrame(sodersh_frame, text="Алфавит", width=150)
bukvi_frame.pack(side=tk.LEFT, fill=tk.Y, padx=5, pady=5)
bukvi_frame.pack_propagate(False)

info_frame = ttk.Frame(sodersh_frame)
info_frame.pack(side=tk.RIGHT, fill=tk.BOTH, expand=True, padx=5, pady=5)

rus_alpavit = ['А','Б','В','Г','Д','Е','Ё','Ж','З','И','Й','К','Л','М','Н','О','П','Р','С','Т','У','Ф','Х','Ц','Ч','Ш','Щ','Э','Ю','Я']

col1 = ttk.Frame(bukvi_frame)
col1.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
col2 = ttk.Frame(bukvi_frame)
col2.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)

def pokaz_info(perem):
    for vidget in text_frame.winfo_children():
        vidget.destroy()
    for vidget in image.winfo_children():
        vidget.destroy()
    
    metka.config(text=f"{perem} - {slovar.get(perem, {}).get('title', '')}")
    
    text_scroll = ttk.Scrollbar(text_frame)
    text_scroll.pack(side=tk.RIGHT, fill=tk.Y)
    
    text2 = tk.Text(
        text_frame,
        wrap=tk.WORD,
        font=('Time New Romans', 14),
        padx=10,
        pady=10,
        yscrollcommand=text_scroll.set
    )
    text2.pack(fill=tk.BOTH, expand=True)
    
    text_scroll.config(command=text2.yview)
    
    text2.insert(tk.END, slovar.get(perem, {}).get('content', 'Информация отсутствует'))
    text2.config(state='disabled')
    
    if perem in slovar and 'image' in slovar[perem]:
        try:
            img = Image.open(slovar[perem]['image'])
            img = img.resize((400, 300), Image.Resampling.LANCZOS)
            photo = ImageTk.PhotoImage(img)
            
            img2 = tk.Label(image, image=photo)
            img2.image = photo
            img2.pack(pady=10, padx=10)
        except:
            osibka = tk.Label(image, text="Изображение не найдено", fg='red')
            osibka.pack()

for i, perem in enumerate(rus_alpavit):
    frame = col1 if i < 15 else col2
    knopki = ttk.Button(frame, text=perem, width=3, command=lambda glpt=perem: pokaz_info(glpt))
    knopki.pack(pady=2)

metka = ttk.Label(info_frame, font=('Time New Romans', 16, 'bold'), wraplength=600)
metka.pack(pady=10, anchor='w')

ttk.Separator(info_frame, orient='horizontal').pack(fill=tk.X, pady=5)

vnutr_frame = ttk.Frame(info_frame)
vnutr_frame.pack(fill=tk.BOTH, expand=True)

text_frame = ttk.Frame(vnutr_frame)
text_frame.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)

image = ttk.Frame(vnutr_frame, width=320)
image.pack(side=tk.RIGHT, fill=tk.Y)
image.pack_propagate(False)

metka.config(text="Выберите букву")

initial_scroll = ttk.Scrollbar(text_frame)
initial_scroll.pack(side=tk.RIGHT, fill=tk.Y)

nachal_text = tk.Text(
    text_frame,
    wrap=tk.WORD,
    font=('Time New Romans', 14),
    padx=10,
    pady=10,
    yscrollcommand=initial_scroll.set
)
nachal_text.pack(fill=tk.BOTH, expand=True)

initial_scroll.config(command=nachal_text.yview)

nachal_text.insert(tk.END, "Выберите букву из алфавита слева для просмотра информации")
nachal_text.config(state='disabled')

glav_okn.mainloop()