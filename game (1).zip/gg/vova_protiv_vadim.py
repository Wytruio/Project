import pygame
import random

pygame.init()

w, h = 600, 800
white = (255, 255, 255)

screen = pygame.display.set_mode((w, h))
pygame.display.set_caption("ВОВА ПРОТИВ ВАДИКА")

clock = pygame.time.Clock()

p_img = pygame.image.load('12.png')
b_img = pygame.image.load('10.png')
bg_img = pygame.image.load('11.png')  

p_w, p_h = p_img.get_size()  
p_x, p_y = w // 2 - p_w // 2, h - p_h - 10
p_speed = 5

b_w, b_h = b_img.get_size()  
b_speed = 5

spawn_sound = pygame.mixer.Sound('spawn.wav')
death_sound = pygame.mixer.Sound('death.wav')

pygame.mixer.music.load('sound.wav')  
pygame.mixer.music.play(-1)  

def game():
    global p_x, p_y
    
    p_x, p_y = w // 2 - p_w // 2, h - p_h - 10
    blocks = []
    score = 0

    running = True
    while running:
        screen.blit(bg_img, (0, 0))

        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False

        keys = pygame.key.get_pressed()
        if keys[pygame.K_LEFT] and p_x > 0:
            p_x -= p_speed
        if keys[pygame.K_RIGHT] and p_x < w - p_w:
            p_x += p_speed

        if random.random() < 0.02:
            b_x = random.randint(0, w - b_w)
            blocks.append([b_x, 0])
            spawn_sound.play()

        for block in blocks[:]:
            block[1] += b_speed
            if block[1] > h:
                blocks.remove(block)
                score += 1
            if (block[0] < p_x + p_w and 
                block[0] + b_w > p_x and 
                block[1] < p_y + p_h and 
                block[1] + b_h > p_y):
                death_sound.play()
             
                pygame.time.delay(800)  
                
                running = False

        screen.blit(p_img, (p_x, p_y))

        for block in blocks:
            screen.blit(b_img, (block[0], block[1]))

        pygame.display.update()
        clock.tick(70)

    pygame.quit()

game()